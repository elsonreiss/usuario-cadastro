package com.elsonnreiss.teste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
